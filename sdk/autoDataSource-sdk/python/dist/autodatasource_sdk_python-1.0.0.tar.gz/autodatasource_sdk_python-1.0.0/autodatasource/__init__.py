import requests
import json

class AutoDataSourceClient:
    """AutoDataSource Python SDK 客户端"""
    
    def __init__(self, base_url):
        """初始化客户端
        
        Args:
            base_url: AutoDataSource API 基础 URL
        """
        self.base_url = base_url
        self.session = requests.Session()
    
    def get_data_sources(self):
        """获取数据源列表
        
        Returns:
            dict: 数据源列表响应
        """
        url = f"{self.base_url}/api/data-sources/external/list"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()
    
    def transform_sql(self, sql, source_type, target_type):
        """转换 SQL 语句
        
        Args:
            sql: SQL 语句
            source_type: 源数据库类型
            target_type: 目标数据库类型
            
        Returns:
            dict: SQL 转换响应
        """
        url = f"{self.base_url}/api/sql/transform"
        data = {
            "sql": sql,
            "sourceType": source_type,
            "targetType": target_type
        }
        response = self.session.post(url, json=data)
        response.raise_for_status()
        return response.json()
    
    def get_data_items(self):
        """获取数据项列表
        
        Returns:
            dict: 数据项列表响应
        """
        url = f"{self.base_url}/api/data-items/list"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()
    
    def get_data_by_uuid(self, uuid_auto_data):
        """根据 UUID 获取数据
        
        Args:
            uuid_auto_data: 数据项 UUID
            
        Returns:
            dict: 数据响应
        """
        url = f"{self.base_url}/api/data-items/data/{uuid_auto_data}"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()
    
    def get_oss_files(self, prefix=None):
        """获取 OSS 文件列表
        
        Args:
            prefix: 目录前缀
            
        Returns:
            dict: OSS 文件列表响应
        """
        url = f"{self.base_url}/api/oss/files"
        if prefix:
            url += f"?prefix={prefix}"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()
    
    def get_public_docs_list(self):
        """获取公共文档列表
        
        Returns:
            dict: 文档列表响应
        """
        url = f"{self.base_url}/docs-public/list"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()
    
    def get_public_doc_content(self, file_name):
        """获取公共文档内容
        
        Args:
            file_name: 文件名
            
        Returns:
            dict: 文档内容响应
        """
        url = f"{self.base_url}/docs-public/docs?fileName={file_name}"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()
    
    def preview_data_items_by_data_source_id(self, data_source_id):
        """根据数据源ID预览数据项
        
        Args:
            data_source_id: 数据源ID
            
        Returns:
            dict: 数据项预览响应
        """
        url = f"{self.base_url}/api/data-items/preview/{data_source_id}"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()

__all__ = ['AutoDataSourceClient']
