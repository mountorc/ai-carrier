package autodatasource

import (
	"encoding/json"
	"fmt"

	"github.com/go-resty/resty/v2"
)

// AutoDataSourceClient AutoDataSource Go SDK 客户端
type AutoDataSourceClient struct {
	baseURL string
	client  *resty.Client
}

// NewClient 创建新的 AutoDataSource 客户端
func NewClient(baseURL string) *AutoDataSourceClient {
	client := resty.New()
	return &AutoDataSourceClient{
		baseURL: baseURL,
		client:  client,
	}
}

// Response 统一响应结构
type Response struct {
	Success  bool        `json:"success"`
	Data     interface{} `json:"data,omitempty"`
	DataList interface{} `json:"dataList,omitempty"`
	Message  string      `json:"message,omitempty"`
}

// GetDataSources 获取数据源列表
func (c *AutoDataSourceClient) GetDataSources() (map[string]interface{}, error) {
	url := fmt.Sprintf("%s/api/data-sources/external/list", c.baseURL)

	resp, err := c.client.R().Get(url)
	if err != nil {
		return nil, err
	}

	var result map[string]interface{}
	if err := json.Unmarshal(resp.Body(), &result); err != nil {
		return nil, err
	}

	return result, nil
}

// TransformSqlRequest SQL 转换请求
type TransformSqlRequest struct {
	Sql        string `json:"sql"`
	SourceType string `json:"sourceType"`
	TargetType string `json:"targetType"`
}

// TransformSqlResponse SQL 转换响应
type TransformSqlResponse struct {
	TransformedSql string `json:"transformedSql"`
}

// TransformSql 转换 SQL 语句
func (c *AutoDataSourceClient) TransformSql(sql, sourceType, targetType string) (*Response, error) {
	url := fmt.Sprintf("%s/api/sql/transform", c.baseURL)

	req := TransformSqlRequest{
		Sql:        sql,
		SourceType: sourceType,
		TargetType: targetType,
	}

	resp, err := c.client.R().
		SetHeader("Content-Type", "application/json").
		SetBody(req).
		Post(url)

	if err != nil {
		return nil, err
	}

	var response Response
	if err := json.Unmarshal(resp.Body(), &response); err != nil {
		return nil, err
	}

	return &response, nil
}

// GetDataItems 获取数据项列表
func (c *AutoDataSourceClient) GetDataItems() (*Response, error) {
	url := fmt.Sprintf("%s/api/data-items/list", c.baseURL)

	resp, err := c.client.R().Get(url)
	if err != nil {
		return nil, err
	}

	var response Response
	if err := json.Unmarshal(resp.Body(), &response); err != nil {
		return nil, err
	}

	return &response, nil
}

// GetDataByUuid 根据 UUID 获取数据
func (c *AutoDataSourceClient) GetDataByUuid(uuidAutoData string) (*Response, error) {
	url := fmt.Sprintf("%s/api/data-items/data/%s", c.baseURL, uuidAutoData)

	resp, err := c.client.R().Get(url)
	if err != nil {
		return nil, err
	}

	var response Response
	if err := json.Unmarshal(resp.Body(), &response); err != nil {
		return nil, err
	}

	return &response, nil
}

// GetOssFiles 获取 OSS 文件列表
func (c *AutoDataSourceClient) GetOssFiles(prefix string) (*Response, error) {
	url := fmt.Sprintf("%s/api/oss/files", c.baseURL)
	if prefix != "" {
		url = fmt.Sprintf("%s?prefix=%s", url, prefix)
	}

	resp, err := c.client.R().Get(url)
	if err != nil {
		return nil, err
	}

	var response Response
	if err := json.Unmarshal(resp.Body(), &response); err != nil {
		return nil, err
	}

	return &response, nil
}

// GetPublicDocsList 获取公共文档列表
func (c *AutoDataSourceClient) GetPublicDocsList() (map[string]interface{}, error) {
	url := fmt.Sprintf("%s/docs-public/list", c.baseURL)

	resp, err := c.client.R().Get(url)
	if err != nil {
		return nil, err
	}

	var result map[string]interface{}
	if err := json.Unmarshal(resp.Body(), &result); err != nil {
		return nil, err
	}

	return result, nil
}

// GetPublicDocContent 获取公共文档内容
func (c *AutoDataSourceClient) GetPublicDocContent(fileName string) (map[string]interface{}, error) {
	url := fmt.Sprintf("%s/docs-public/docs?fileName=%s", c.baseURL, fileName)

	resp, err := c.client.R().Get(url)
	if err != nil {
		return nil, err
	}

	var result map[string]interface{}
	if err := json.Unmarshal(resp.Body(), &result); err != nil {
		return nil, err
	}

	return result, nil
}

// PreviewDataItemsByDataSourceId 根据数据源ID预览数据项
func (c *AutoDataSourceClient) PreviewDataItemsByDataSourceId(dataSourceId string) (*Response, error) {
	url := fmt.Sprintf("%s/api/data-items/preview/%s", c.baseURL, dataSourceId)

	resp, err := c.client.R().Get(url)
	if err != nil {
		return nil, err
	}

	var response Response
	if err := json.Unmarshal(resp.Body(), &response); err != nil {
		return nil, err
	}

	return &response, nil
}
