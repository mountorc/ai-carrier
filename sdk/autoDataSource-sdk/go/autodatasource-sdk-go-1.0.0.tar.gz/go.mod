module github.com/example/autodatasource-sdk-go

go 1.16

require (
	github.com/go-resty/resty/v2 v2.7.0
)
