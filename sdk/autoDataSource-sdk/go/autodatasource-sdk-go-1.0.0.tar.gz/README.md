# AutoDataSource Go SDK

Go SDK for AutoDataSource API

## 功能特性

- 数据源管理：获取数据源列表
- SQL 转换：不同数据库方言之间的 SQL 语句转换
- 数据项管理：获取数据项列表，根据 UUID 获取数据
- OSS 文件管理：查看 OSS 文件结构
- 文档管理：获取公共文档列表和内容

## 快速开始

### 安装

```bash
go get github.com/example/autodatasource-sdk-go
```

### 使用示例

```go
package main

import (
	"fmt"

	"github.com/example/autodatasource-sdk-go"
)

func main() {
	// 初始化客户端
	baseURL := "http://localhost:8080/autoDataSource"
	client := autodatasource.NewClient(baseURL)

	// 获取数据源列表
	dataSourcesResp, err := client.GetDataSources()
	if err != nil {
		fmt.Printf("获取数据源列表失败: %v\n", err)
	} else {
		fmt.Printf("数据源列表: %+v\n", dataSourcesResp)
	}

	// 转换 SQL 语句
	sql := "SELECT * FROM users LIMIT 10"
	transformResp, err := client.TransformSql(sql, "mysql", "oracle")
	if err != nil {
		fmt.Printf("转换 SQL 失败: %v\n", err)
	} else {
		fmt.Printf("原始 SQL: %s\n", sql)
		if data, ok := transformResp.Data.(map[string]interface{}); ok {
			fmt.Printf("转换后 SQL: %s\n", data["transformedSql"])
		}
	}

	// 获取数据项列表
	dataItemsResp, err := client.GetDataItems()
	if err != nil {
		fmt.Printf("获取数据项列表失败: %v\n", err)
	} else {
		fmt.Printf("数据项列表: %+v\n", dataItemsResp)
	}

	// 获取 OSS 文件列表
	ossFilesResp, err := client.GetOssFiles("")
	if err != nil {
		fmt.Printf("获取 OSS 文件列表失败: %v\n", err)
	} else {
		fmt.Printf("OSS 文件列表: %+v\n", ossFilesResp)
	}

	// 获取公共文档列表
	docsListResp, err := client.GetPublicDocsList()
	if err != nil {
		fmt.Printf("获取公共文档列表失败: %v\n", err)
	} else {
		fmt.Printf("公共文档列表: %+v\n", docsListResp)
	}
}
```

## API 文档

### AutoDataSourceClient

#### NewClient 创建新的 AutoDataSource 客户端

```go
func NewClient(baseURL string) *AutoDataSourceClient
```

- `baseURL`: AutoDataSource API 基础 URL，例如 `http://localhost:8080/autoDataSource`

#### 方法

1. **获取数据源列表**

   ```go
   func (c *AutoDataSourceClient) GetDataSources() (map[string]interface{}, error)
   ```

2. **转换 SQL 语句**

   ```go
   func (c *AutoDataSourceClient) TransformSql(sql, sourceType, targetType string) (*Response, error)
   ```

   - `sql`: 要转换的 SQL 语句
   - `sourceType`: 源数据库类型，例如 `mysql`、`oracle` 等
   - `targetType`: 目标数据库类型，例如 `mysql`、`oracle` 等

3. **获取数据项列表**

   ```go
   func (c *AutoDataSourceClient) GetDataItems() (*Response, error)
   ```

4. **根据 UUID 获取数据**

   ```go
   func (c *AutoDataSourceClient) GetDataByUuid(uuidAutoData string) (*Response, error)
   ```

   - `uuidAutoData`: 数据项 UUID

5. **获取 OSS 文件列表**

   ```go
   func (c *AutoDataSourceClient) GetOssFiles(prefix string) (*Response, error)
   ```

   - `prefix`: 目录前缀，可为空字符串

6. **获取公共文档列表**

   ```go
   func (c *AutoDataSourceClient) GetPublicDocsList() (map[string]interface{}, error)
   ```

7. **获取公共文档内容**

   ```go
   func (c *AutoDataSourceClient) GetPublicDocContent(fileName string) (map[string]interface{}, error)
   ```

   - `fileName`: 文件名

## 响应结构

### Response 统一响应结构

```go
type Response struct {
	Success bool        `json:"success"`
	Data    interface{} `json:"data"`
	Message string      `json:"message"`
}
```

## 错误处理

SDK 会返回 `error` 类型的错误，建议在使用时进行适当的错误处理。

## 版本历史

- v1.0.0: 初始版本

## 下载地址

[AutoDataSource Go SDK v1.0.0](sdk/go/autodatasource-sdk-go-1.0.0.tar.gz)
